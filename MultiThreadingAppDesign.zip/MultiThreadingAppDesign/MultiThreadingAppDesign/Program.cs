﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MultiThreadingAppDesign
{
    internal class Program
    {
        static void Main(string[] args)
        {
           Stopwatch sw= Stopwatch.StartNew();
            SpellCheckerApp sca = new SpellCheckerApp();
            
            sca.InputFile = "random_val.txt";
            sca.StartSpellCheck(sca.InputFile,sca.OutputFile);
            Console.WriteLine(sw.ElapsedMilliseconds);
            Console.WriteLine("done successfully");
        }
    }
    public class SpellCheckerApp
    {
        public string InputFile { get; set; }
        public string OutputFile { get; set; }
        /*public InputFileLoader inputFileLoader{ get; set; }*/
        /*public SpellChecker spellChecker { get; set; }*/
        SpellChecker sp = new SpellChecker("english-words.95");
        
       
            
            
       
        public void StartSpellCheck(string inputFile, string outputFile)
        {
            List<string> ls = InputFileLoader.Load(inputFile);

            using (StreamWriter sw = new StreamWriter(@"C:\Users\PANDURANGA\Downloads\outpu.txt"))
            {
                foreach (var item in ls)
                {
                    List<string> l = sp.Check(item);
                    sw.WriteLine(item);
                    foreach (var i in l)
                    {
                        sw.WriteLine("\t"+i);
                    }
                    Console.WriteLine("Came");
                    
                }
                
            }

        }
    }
    public class SpellChecker
    {
        /*public DictionaryFileLoader dictionaryFileLoader { get; set; }*/
        /*  public LevenshteinDistance levenshteinDistance { get; set; }*/
        public static List<string> words = new List<string>();

        public SpellChecker(string OutPutFile)
        {
            words = DictionaryFileLoader.Load(OutPutFile);
        }

        LevenshteinDistance l = new LevenshteinDistance();
   

        public List<string> Check(string s)
        {
            List<string> ans = new List<string>();

            //foreach (var item in words)
                Parallel.ForEach(words, (x) =>
                {



                    if (l.CalculateDistance(s, x) <= 2)
                        ans.Add(x);


                });
            
            ans = ans.OrderBy((x) => l.CalculateDistance(s, x)).Take(10).ToList();
           /* foreach(var item in ans)
                Console.WriteLine(item);*/
           
            return ans;

           



            
        }
    }
    public class LevenshteinDistance
    {
        public int CalculateDistance(string s1, string s2)
        {
            List<List<int>> dp = new List<List<int>>();
            for (int i = 0; i < s1.Length + 1; i++)
            {
                dp.Add(new List<int>());
                for (int j = 0; j < s2.Length+ 1; j++)
                {
                    dp[i].Add(-1);
                }
            }

            return minDis(s1, s2, s1.Length, s2.Length, dp);
        }



        static int minDis(string s1, string s2, int n, int m,
                        List<List<int>> dp)
        {

            // If any string is empty,
            // return the remaining characters of other string
            if (n == 0)
                return m;

            if (m == 0)
                return n;

            // To check if the recursive tree
            // for given n & m has already been executed
            if (dp[n][m] != -1)
                return dp[n][m];

            // If characters are equal, execute
            // recursive function for n-1, m-1
            if (s1[n - 1] == s2[m - 1])
            {
                if (dp[n - 1][m - 1] == -1)
                {
                    return dp[n][m]
                        = minDis(s1, s2, n - 1, m - 1, dp);
                }
                else
                    return dp[n][m] = dp[n - 1][m - 1];
            }

            // If characters are nt equal, we need to
            // find the minimum cost out of all 3 operations.
            else
            {
                int m1, m2, m3; // temp variables

                if (dp[n - 1][m] != -1)
                {
                    m1 = dp[n - 1][m];
                }
                else
                {
                    m1 = minDis(s1, s2, n - 1, m, dp);
                }

                if (dp[n][m - 1] != -1)
                {
                    m2 = dp[n][m - 1];
                }
                else
                {
                    m2 = minDis(s1, s2, n, m - 1, dp);
                }

                if (dp[n - 1][m - 1] != -1)
                {
                    m3 = dp[n - 1][m - 1];
                }
                else
                {
                    m3 = minDis(s1, s2, n - 1, m - 1, dp);
                }
                return dp[n][m]
                    = 1 + Math.Min(m1, Math.Min(m2, m3));
            }
        }


    }

    // This code is contributed by divyeshrabadiya07.


}
public class InputFileLoader
        {
        static List<string> inputFiles = new List<string>();   
        public static List<string> Load(string s)
        {
            using(StreamReader sr=new StreamReader(s))
            {
                while (!sr.EndOfStream)
                {
                    string line = sr.ReadLine();
                    inputFiles.Add(line);

                }

            }
            return inputFiles;
        }
    }
    public class DictionaryFileLoader
    {
        static List<string> OutputFiles = new List<string>();
        public static List<string> Load(string s)
        {
            
                using (StreamReader sr = new StreamReader(s))
                {
                    while (!sr.EndOfStream)
                    {
                        string line = sr.ReadLine();
                        OutputFiles.Add(line);

                    }

                }
                return OutputFiles;
            

        }
    }


